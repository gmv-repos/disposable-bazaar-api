import ReactDOM from 'react-dom/client';
import Main from "./Main";
import { BrowserRouter } from 'react-router-dom';
import '../../assets/adminPanel/css/index.css'
import { UserProvider } from './Context/UserContext';
import { WishlistProvider } from './Context/WishlistContext';
import { CartProvider } from './Context/CartContext';
import { GoogleOAuthProvider } from '@react-oauth/google';


ReactDOM.createRoot(document.getElementById('app')).render(

    //  basename='ecommerce-inventory'

    <BrowserRouter basename='ecommerce-inventory'>
        <GoogleOAuthProvider clientId='341574951595-7kmbo799rdp05d4dcjgn0vfkpfsrrs44.apps.googleusercontent.com'>
            <UserProvider>
                <CartProvider>
                    <WishlistProvider>
                        <Main />
                    </WishlistProvider>
                </CartProvider>
            </UserProvider>
        </GoogleOAuthProvider>
    </BrowserRouter>
);