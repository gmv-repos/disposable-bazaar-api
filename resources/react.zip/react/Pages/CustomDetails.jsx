import React, { useEffect, useState } from 'react'
import { Assets_Url, Image_Url } from '../const'
import axios from '../Utils/axios'
import './Pages.css'
import { FaCircle, FaWhatsapp } from 'react-icons/fa'
import RcmdProduct from '../components/Shop/RcmdProduct'
import Deals from '../components/Home/Deals'
import Review from '../components/Reviews/Review'
import { PiCaretDownThin, PiCaretUpThin } from 'react-icons/pi'
import { TbCameraPlus } from 'react-icons/tb'
import { BiSolidImageAdd } from 'react-icons/bi'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useUser } from '../Context/UserContext'
import { useCart } from '../Context/CartContext'
import { useWishlist } from '../Context/WishlistContext'
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; // Import the CSS for Toastify
import { FiX } from 'react-icons/fi'
import { CartModal } from '../components/cart/CartModal'

function CustomDetails() {
    const [productDetail, setProductDetail] = useState([])
    const [recomendedProducts, setRecomendedProducts] = useState([]);
    const [productImages, setProductImages] = useState([]);
    const [productOptions, setProductOptions] = useState([]);
    const [productVariants, setProductVariants] = useState([]);
    const [productLid, setProductLid] = useState([]);
    const [selectedImage, setSelectedImage] = useState('') // State to track the selected image
    // const [quantity, setQuantity] = useState('25 Pcs')
    const [subQuantity, setSubQuantity] = useState(1)
    const [productTextDetail, setProductTextDetail] = useState('Description')
    const [piecesDropdown, setPiecesDropdown] = useState(false); // State to toggle pieces dropdown
    const [lidsDropdown, setLidsDropdown] = useState(false); // State to toggle pieces dropdown
    const [selectedPackSize, setSelectedPackSize] = useState('');
    const [selectedPackPrice, setSelectedPackPrice] = useState();
    const [selectedLid, setSelectedLid] = useState('');
    const [selectedLidPrice, setSelectedLidPrice] = useState();
    const [selectedLidId, setSelectedLidId] = useState(null);
    const [sizeDropdown, setSizeDropdown] = useState(false); // State to toggle size dropdown
    const [selectedSize, setSelectedSize] = useState('');
    const [colors, setColors] = useState(false)
    const [selectedColor, setSelectedColor] = useState('');
    const [selectedOptionPrice, setSelectedOptionPrice] = useState();
    const [designText, setDesignText] = useState('Add Your Design'); // Default text
    const [uploadedFile, setUploadedFile] = useState(null); // Store uploaded file
    const [logoImage, setLogoImage] = useState(null); // State to store the logo
    const [customizeDetail, setCustomizeDetail] = useState('')

    // Fetch productId from the URL using useParams
    const { id } = useParams();
    const { addToWishlist } = useWishlist();
    const { addToCart } = useCart();
    const [isCartModalOpen, setIsCartModalOpen] = useState(false);
    const { user } = useUser();
    const navigate = useNavigate()

    // const descriptionList = [
    //     { li: 'Sturdy & Strong: Made from high-quality styrene for durability.', },
    //     { li: 'Leak Proof: Ensures no spills or messes.', },
    //     { li: 'Microwave Note: Safe for microwave use.', },
    //     { li: 'Freezer Note: Suitable for storing food in the freezer.', },
    //     { li: 'Packaging: Conveniently stackable for easy storage.', },
    //     { li: 'End of Life: Dispose of responsibility to reduce environmental impact', },
    // ]

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.public.get(`product/customize/s/${id}/details`)
                setProductDetail(response.data.data)
                setProductImages(response.data.data?.product.product_image)
                setProductOptions(response.data.data.product.product_options)
                setProductVariants(response.data.data.product.product_variants)
                setProductLid(response.data.data.product?.product_lid_options)


                setSelectedPackSize(response.data.data.product.product_variants[0].pack_size)
                setSelectedPackPrice(response.data.data.product.product_variants[0].price_per_piece)
                // setSelectedLid(response.data.data.product.product_lid_options[0].name)
                // setSelectedLidPrice(response.data.data.product.product_lid_options[0].price)
                console.log(response.data.data);

                setRecomendedProducts(response.data.data.recommended_products)
                // Set the initial selected image to the first product image or a placeholder
                setSelectedImage(response.data.data?.product.product_image[0].image || '')
            } catch (error) {
                console.log(error);
            }
        }
        fetchData()
    }, [])

    const handleSubmit = (e) => {
        e.preventDefault()
    }

    const handleImageClick = (image) => {
        setSelectedImage(image) // Update the selected image when clicked
    }

    const handleWishlist = async (id) => {
        if (!user) {
            navigate('/login');
            return;
        }

        try {
            // Make a request to check if the item is already in the wishlist
            const wishlistResponse = await axios.protected.get(`/user/wishlist/${id}/check`);
            console.log(wishlistResponse.data);

            if (wishlistResponse.data.exists) {
                toast.error('Product already added to wishlist');
            } else {
                // If product is not in wishlist, proceed to add it
                const response = await axios.protected.post(`/user/wishlist/${id}/add`);
                if (response.status === 200) {
                    addToWishlist(); // Call to update wishlist count in context
                    toast.success('Product added to wishlist');
                }
            }
        } catch (error) {
            console.log(error);
            toast.error('An error occurred while adding to wishlist');
        }
    };

    // Handle file selection
    const handleFileChange = (e) => {
        const file = e.target.files[0]; // Get the selected file
        if (file) {
            setUploadedFile(file); // Set the selected file to state
            setDesignText('Design uploaded!'); // Update the text after upload
        }
    };

    // Convert File to Base64 and return as a promise
    const convertFileToBase64 = (file) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file); // Convert file to Base64
            reader.onload = () => {
                resolve(reader.result); // Resolve the promise with the Base64 string
            };
            reader.onerror = (error) => {
                reject(error); // Reject the promise if there's an error
            };
        });
    };

    // Handle Add to Cart Logic
    const handleAddCart = async (product) => {
        const product_id = product.id;
        const product_name = product.name;
        const pack_size = selectedPackSize || 1; // Ensure pack size is at least 1
        const product_quantity = subQuantity || 1; // Ensure subQuantity is at least 1
        const total_pieces = Number(pack_size) * Number(product_quantity);

        // Ensure selectedPackPrice and selectedOptionPrice are valid numbers
        const price_per_piece = Number(selectedPackPrice ? selectedPackPrice : 0)  ;

        // Calculate product total with valid numbers
        const product_total = (Number(total_pieces) *  ( Number(price_per_piece) + Number(selectedOptionPrice ? selectedOptionPrice : 0) + Number(selectedLidPrice ? selectedLidPrice : 0) )).toFixed(2);

        const product_img = product.image_path;
        const product_variants = productVariants;
        const product_options = productOptions;
        const product_color = selectedColor || null;
        const product_size = selectedSize || null;
        const product_lids = productLid ? productLid : null;
        const lid = selectedLidId ? selectedLidId : null;
        const lid_Price = selectedLidPrice ? selectedLidPrice : null;
        const custom_Note = customizeDetail ? customizeDetail : null;
        // const product_lids = productLids ? productLids : null;
        // const lid = selectedLidId ? selectedLidId : null;
        const option_Price = selectedOptionPrice ? selectedOptionPrice : 0;
        let logo = null;

        // If there's an uploaded file (logo), convert it to Base64
        if (uploadedFile) {
            try {
                logo = await convertFileToBase64(uploadedFile); // Await the file conversion
            } catch (error) {
                console.error('Error converting logo to Base64:', error);
            }
        }
        if (selectedSize === '') {
            toast.error(`Select a size`);
        } else if (selectedColor === '') {
            toast.error(`Select a Color`);
        } else if (uploadedFile === null) {
            toast.error(`Select a file`);
        }
        // else if (customizeDetail === '') {
        //     toast.error(`Select a file`);
        // }
        else {
            // Add the product to the cart
            addToCart(
                product_id,
                product_name,
                product_quantity,
                pack_size,
                total_pieces,
                price_per_piece,
                product_img,
                product_total,
                product_variants,
                product_color,
                product_size,
                logo, // You can store the logo file in the cart as needed
                product_options,
                product_lids,
                lid,
                lid_Price,
                customizeDetail,
                option_Price,


            );
            setSelectedSize('');
            setSelectedColor('');
            setUploadedFile('');
            setCustomizeDetail('');
            document.getElementById('upload-image').value = '';
            // Show success toast
            setIsCartModalOpen(true)
            // toast.success(`${product.name} added to cart`);
        }

    };

    // console.log(quantity)
    // console.log(subQuantity)
    return (
        <div className="relative py-32 px-10 text-white overflow-hidden">
            <ToastContainer autoClose={500} />
            {/* Breadcrumb and Title */}
            <div className="flex flex-col py-5">
                <p><Link to='/'>Home</Link> / <Link to='/customization'>Customization</Link> / {productDetail.product?.name || 'Product Name'} </p>
                {/* <h1 className="py-10 font-bazaar md:text-6xl text-5xl">INQUIRY FORM</h1> */}
            </div>
            <main className=''>
                <section className='flex lg:flex-row flex-col gap-8'>
                    {/* Thumbnail Section */}
                    <div className="lg:w-3/5 md:h-[34rem] h-[20rem] flex flex-row md:gap-5 gap-2">
                        <div className="w-1/5 flex flex-col gap-1">
                            {Array.isArray(productImages) && productImages.length === 0 ? (
                                // If productImages is an empty array, show the default image
                                <div className="w-full h-1/4 py-1">
                                    <img
                                        className="w-full h-full bg-[#32303e] rounded-xl border-2 border-[#1E7773] object-cover cursor-pointer"
                                        src={`${Image_Url}defaultImage.svg`} // Default image when no products
                                        alt="Default Product Image"
                                    />
                                </div>
                            ) : (
                                // If productImages is not empty, map over the images and display them
                                productImages.slice(0, 4).map((prod, index) => (
                                    <div key={index} className="w-full h-1/4 py-1">
                                        <img
                                            className="w-full h-full bg-[#32303e] rounded-xl border-2 border-[#1E7773] object-cover cursor-pointer"
                                            // If the prod.image array is empty, use the default image; otherwise, use the first image in the array
                                            src={`${Assets_Url}${prod.image}`}
                                            alt="Product Image"
                                            onClick={() => handleImageClick(prod.image)} // Set clicked image (first image in the array)
                                        />

                                    </div>
                                ))
                            )}
                        </div>
                        {/* Large Image Display */}
                        <div className="w-4/5 rounded-lg bgblack ">
                            {selectedImage && (
                                <img
                                    className="w-full h-full object-cover rounded-lg"
                                    src={`${Assets_Url}${selectedImage}`} // Show selected image
                                    alt="Selected Product"
                                />
                            )}
                        </div>
                    </div>
                    <div className="lg:w-[55%] flex flex-col gap-5 text-white h[300px]">
                        <h1 className='md:text-5xl text-3xl font-semibold'>{productDetail.product?.name || 'Product Name'}</h1>
                        <h3 className='md:text-xl text-md font-semibold'>
                           Brand : {productDetail.product?.brand_name || 'Brand Name'}
                        </h3>
                        <p className='text-xl font-semibold'>
                            {productVariants && productVariants.length > 0 ? (
                                <>
                                    Rs {productVariants[0].price} - {productVariants[productVariants.length - 1].price}
                                    {/* ₨ {quantity && selectedVariantPrice && (quantity * subQuantity * selectedVariantPrice)} */}
                                </>
                            ) : (
                                <span>No variants available</span>
                            )}
                        </p>
                        <form onSubmit={handleSubmit} className='w-3/4 flex flex-col gap-5'>
                            <div className="flex mdflex-row flex-wrap gap-3">
                            {productLid?.length > 0 && (
                            <div className="relative">
                                    {/* Dropdown button for Lid */}
                                    <h3
                                        onClick={() => setLidsDropdown(!lidsDropdown)}
                                        className="flex flex-row justify-between items-center text-md gap-3 border p-2 rounded-md md:w-28 w-40 border-[#1E7773]">
                                        <p>{selectedLid ? selectedLid : 'Lids'} </p> {/* Show selected pack size or default text */}
                                        <p>{lidsDropdown ? <PiCaretUpThin /> : <PiCaretDownThin />}</p>
                                    </h3>

                                    {/* Dropdown options for Lid */}
                                    {lidsDropdown && (
                                        <div className="md:w-28 w-40 rounded-md my-2 h-32 absolute z-10 overflow-auto bg-white text-black">
                                            {productLid.map((lid) => (
                                                <div
                                                    key={lid.id}
                                                    className="p-2 cursor-pointer hover:bg-gray-200"
                                                    onClick={() => {
                                                        setSelectedLidId(lid.id); // Set selected lid on click
                                                        setSelectedLidPrice(lid.price);
                                                        setSelectedLid(lid.name);
                                                        console.log(selectedLidPrice);

                                                        setLidsDropdown(false); // Close dropdown after selection
                                                    }}>
                                                    {lid.name}  {/* Display the pack size option */}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                )}
                                {/* <div className="relative">
                                    <h3 onClick={() => setPieces(!pieces)} className="flex flex-row justify-between items-center text-md gap-3 border p-2 rounded-md md:w-24 w-40 border-[#1E7773] "><p>Pieces</p><p>{pieces ? <PiCaretUpThin /> : <PiCaretDownThin />}</p></h3>
                                    {pieces && (
                                        <div className="md:w-24 w-40  rounded-md my-2 h-32 absolute z-10 overflow-auto bg-white">ssd</div>
                                    )}
                                </div> */}
                                <div className="relative">
                                    {/* Dropdown button for pack size */}
                                    <h3
                                        onClick={() => setPiecesDropdown(!piecesDropdown)}
                                        className="flex flex-row justify-between items-center text-md gap-3 border p-2 rounded-md md:w-24 w-40 border-[#1E7773]">
                                        <p>{selectedPackSize ? selectedPackSize : 'Pieces'} Pcs</p> {/* Show selected pack size or default text */}
                                        <p>{piecesDropdown ? <PiCaretUpThin /> : <PiCaretDownThin />}</p>
                                    </h3>

                                    {/* Dropdown options for pack sizes */}
                                    {piecesDropdown && (
                                        <div className="md:w-24 w-40 rounded-md my-2 h-32 absolute z-10 overflow-auto bg-white text-black">
                                            {productVariants.map((variant) => (
                                                <div
                                                    key={variant.id}
                                                    className="p-2 cursor-pointer hover:bg-gray-200"
                                                    onClick={() => {
                                                        setSelectedPackSize(variant.pack_size); // Set selected pack size
                                                        setSelectedPackPrice(variant.price_per_piece)
                                                        console.log(selectedPackPrice);

                                                        setPiecesDropdown(false); // Close dropdown after selection
                                                    }}>
                                                    {variant.pack_size}  {/* Display the pack size option */}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                {/* <div className="relative">
                                    <h3 onClick={() => setSize(!size)} className="flex flex-row justify-between items-center text-md gap-3 border p-2 rounded-md md:w-24 w-40 border-[#1E7773] "><p>Size</p><p>{size ? <PiCaretUpThin /> : <PiCaretDownThin />}</p></h3>
                                    {size && (
                                        <div className="md:w-24 w-40  rounded-md my-2 h-32 absolute z-10 overflow-auto bg-white">ssd</div>
                                    )}
                                </div> */}
                                <div className="relative">
                                    {/* Dropdown button for size */}
                                    <h3
                                        onClick={() => setSizeDropdown(!sizeDropdown)}
                                        className="flex flex-row justify-between items-center text-md gap-3 border p-2 rounded-md md:w-24 w-40 border-[#1E7773]">
                                        <p>{selectedSize ? selectedSize : 'Size'}</p> {/* Show selected size or default text */}
                                        <p>{sizeDropdown ? <PiCaretUpThin /> : <PiCaretDownThin />}</p>
                                    </h3>

                                    {/* Dropdown options for sizes */}
                                    {sizeDropdown && (
                                        <div className="md:w-24 w-40 rounded-md my-2 h-32 absolute z-10 overflow-auto bg-white text-black">
                                            {[
                                                ...new Set(productOptions.map((option) => option.size))  // Ensure unique size options
                                            ].map((uniqueSize) => (
                                                <div
                                                    key={uniqueSize}
                                                    className="p-2 cursor-pointer hover:bg-gray-200"
                                                    onClick={() => {
                                                        setSelectedSize(uniqueSize); // Set selected size
                                                        const selectedOption = productOptions.find(option => option.size === uniqueSize);
                                                        setSelectedOptionPrice(selectedOption.options_price);  // Set corresponding price
                                                        setSizeDropdown(false); // Close dropdown after selection
                                                    }}>
                                                    {uniqueSize} {/* Display the unique size option */}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>

                                {/* <div className="relative">
                                    <h3 onClick={() => setColors(!colors)} className="flex flex-row justify-between items-center text-md gap-3 border p-2 rounded-md w-40 border-[#1E7773] "><p>Colors Option</p><p>{colors ? <PiCaretUpThin /> : <PiCaretDownThin />}</p></h3>
                                    {colors && (
                                        <div className="w-40  rounded-md my-2 h-32 absolute z-10 overflow-auto bg-white">ssd</div>
                                    )}
                                </div> */}
                                <div className="relative">
                                    {/* Dropdown button */}
                                    <h3
                                        onClick={() => setColors(!colors)}
                                        className="flex flex-row justify-between items-center text-md gap-3 border p-2 rounded-md w-40 border-[#1E7773]">
                                        <p>{selectedColor ? selectedColor : 'Colors Option'}</p> {/* Show selected color or default text */}
                                        <p>{colors ? <PiCaretUpThin /> : <PiCaretDownThin />}</p>
                                    </h3>

                                    {/* Dropdown options */}
                                    {colors && (
                                        <div className="w-40 rounded-md my-2 h-32 absolute z-10 overflow-auto bg-white text-black">
                                            {[
                                                ...new Set(productOptions.map((option) => option.option))  // Ensure unique color options
                                            ].map((uniqueColor) => (
                                                <div
                                                    key={uniqueColor}
                                                    className="p-2 cursor-pointer hover:bg-gray-200"
                                                    onClick={() => {
                                                        setSelectedColor(uniqueColor); // Set selected color
                                                        const selectedOption = productOptions.find(option => option.option === uniqueColor);
                                                        setSelectedOptionPrice(selectedOption.options_price);  // Set corresponding price
                                                        setColors(false); // Close dropdown after selection
                                                    }}>
                                                    {uniqueColor} {/* Display the unique color option */}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>

                            </div>
                            <div
                                id="upload"
                                className="flex flex-col relative md:w-3/2 w[23.5rem] w-full h60 p-5 px-3 items-center justify-center border-2 border-dashed rounded-lg border-[#1E7773]"
                            >
                                <p className="font-bazaar flex flex-row gap-2 pt-1">
                                    <BiSolidImageAdd size={22} />
                                    {designText} {/* Display the updated text */}
                                </p>
                                <input
                                    type="file"
                                    id="upload-image"
                                    name="thumbnail"
                                    accept="image/*"
                                    className="absolute inset-0 opacity-0 cursor-pointer"
                                    onChange={handleFileChange} // Trigger function when a file is selected
                                />
                                {/* Optionally display the file name */}
                                {uploadedFile && (
                                    <p className="text-sm text-gray-500 mt-2">File: {uploadedFile.name}</p>
                                )}
                            </div>
                            <div className="w-full md:md:w-3/2 w[23.5rem]">
                                <textarea className='w-full rounded-lg p-2 outline-none bg-transparent border border-[#1E7773] resize-none' rows={2} placeholder='Additional Customization' name="" id="" value={customizeDetail} onChange={(e) => setCustomizeDetail(e.target.value)}></textarea>
                            </div>
                            <div className='flex flex-row gap-3'>
                                <div className="border border-[#1E7773] rounded-md flex flex-row justify-between items-center px-2 w-24 h-10">
                                    <button disabled={subQuantity === 1} onClick={() => setSubQuantity(subQuantity - 1)}>-</button>
                                    <p className=''>{subQuantity}</p>
                                    <button onClick={() => setSubQuantity(subQuantity + 1)}>+</button>
                                </div>
                                <button className='p-2 pt-3 bg-[#1E7773] w-full lg:text-[15px] font-bazaar text-xs rounded-md'
                                    onClick={() => handleAddCart(productDetail.product)}>
                                    ADD TO CART
                                </button>
                            </div>
                        </form>
                        <p>
                            ₨ {subQuantity && selectedPackPrice && selectedPackSize || selectedOptionPrice 
                                ? ((Number(subQuantity || 1) * Number(selectedPackSize || 1)) * (Number(selectedPackPrice || 1) + Number(selectedOptionPrice ? selectedOptionPrice : 0) + Number(selectedLidPrice ? selectedLidPrice : 0))).toFixed(2)
                                : 0}
                                
                            / Per Pieces: {(Number(selectedPackPrice || 0) + Number(selectedOptionPrice || 0)) + Number(selectedLidPrice || 0)}
                        </p>


                        <div className="flex flex-row md:gap-5 gap-2">
                            <button className='p-2 pt-3 border-b-4 border-[#1E7773] w-32 lg:text-[15px] font-bazaar text-xs' onClick={() => handleWishlist(productDetail.product?.id)}>ADD TO WISHLIST</button>
                            <button className='p-3 border flex flex-row justify-between items-center gap-2  border-[#1E7773] w32 lg:text-[15px]  font-bazaar text-xs rounded-md'><FaWhatsapp className='text-[#1E7773] text-2xl' /> <p className="pt-2">ORDER ON WHATSAPP</p></button>
                        </div>
                        {/* <button className='p-3 pt-3 bg-[#1E7773] w-52 lg:text-[15px] font-bazaar text-xs rounded-md'>CUSTOMIZED PRINTING</button> */}
                    </div>
                </section>
                {/* Product Description and Additional Information */}
                <section className='flex flex-col gap-8 md:py-20 py-5'>
                    <div className="flex flexrow w-full border-b border-[#1E7773] justify-center items-center">
                        <div className="flex flex-row justify-center md:gap-5 gap-2 items-center">
                            <h1 onClick={() => setProductTextDetail('Description')} className={`font-bazaar py-2 ${productTextDetail === 'Description' ? ' border-b-2 border-[#1E7773]' : 'text-[#55555F]'} md:text-xl text-xs`}>Product Description </h1>
                            <h1 onClick={() => setProductTextDetail('Additional information')} className={`font-bazaar py-2 ${productTextDetail === 'Additional information' ? ' border-b-2 border-[#1E7773]' : 'text-[#55555F]'} md:text-xl text-xs`}>Additional information</h1>
                            <h1 onClick={() => setProductTextDetail('Watch Product Video')} className={`font-bazaar py-2 ${productTextDetail === 'Watch Product Video' ? ' border-b-2 border-[#1E7773]' : 'text-[#55555F]'} md:text-xl text-xs`}>Watch Product Video</h1>
                        </div>
                    </div>
                    <div>
                        {productTextDetail === 'Description' && (
                            <div className="flex flex-col gap-2">
                                {productDetail.product?.description ? (
                                    <p
                                        dangerouslySetInnerHTML={{
                                            __html: productDetail.product.description,
                                        }}
                                        className="text-md"
                                    />
                                ) : (
                                    <p className="text-md">No Description Found</p>
                                )}
                            </div>
                        )}
                        {productTextDetail === 'Additional information' && (
                            <div className="flex flex-col gap-2">
                                {productDetail.product?.additional_information ? (
                                    <p
                                        dangerouslySetInnerHTML={{
                                            __html: productDetail.product.additional_information,
                                        }}
                                        className="text-md"
                                    />
                                ) : (
                                    <p className="text-md">No Additional Information Found</p>
                                )}
                            </div>
                        )}

                        {productTextDetail === 'Watch Product Video' && (
                            <div className="flex flex-col gap-2">
                                {productDetail.product?.product_video_url ? (
                                    <iframe
                                        className="w-full h-96"
                                        src={`https://www.youtube.com/embed/${productDetail.product.product_video_url.split('v=')[1]}`}
                                        title="Product Video"
                                        frameBorder="0"
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                        allowFullScreen
                                    />
                                ) : (
                                    <p>No Video Found</p>
                                )}

                            </div>
                        )}



                        {/* Add content for 'Additional information' and 'Watch Product Video' */}
                    </div>
                </section>
                {recomendedProducts.length === 0 ? (
                    <h1 className='text-center text-4xl py-10 font-bazaar'>No Related Product Found</h1>
                ) : (
                    <>

                        <RcmdProduct products={recomendedProducts} />
                    </>
                )}

                <div className="relative z-10">
                    <Deals />
                </div>
                <Review />
            </main>
            {/* Background Image */}
            <img
                data-aos="fade-left"
                className="absolute top-[44rem] right-0 md:w-28 w-16"
                src={`${Image_Url}plateRight.svg`}
                alt="Plate"
            />
            <img
                data-aos="fade-right"
                className="absolute top-[100rem] left-0 lg:w-16 w-8"
                src={`${Image_Url}leftCup.svg`}
                alt="Plate"
            />
            <img
                // data-aos="fade-left"
                className="absolute z-0 top-[100rem] right-0 w-full h-screen"
                src={`${Image_Url}ShopAssets/bgGradient.svg`}
                alt="bgGradient"
            />
            {isCartModalOpen && (
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 text-black" onClick={() => setIsCartModalOpen(false)}>
                    <div className="fixed md:top-4 md:right-4 bg-white shadow-lg p-4 rounded-lg z-50 w-[300px] transition-transform duration-500">
                        <div className='flex justify-between  text-black'>
                            <h4 className="text-md font-bold">Added to Cart</h4>
                            <FiX size={24} onClick={() => setIsCartModalOpen(false)} />
                        </div>
                        <CartModal />
                    </div>
                </div>
            )}
        </div>
    )
}

export default CustomDetails