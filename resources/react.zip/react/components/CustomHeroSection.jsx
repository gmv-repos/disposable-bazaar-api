import React, { useEffect } from 'react'
import { Image_Url } from '../const'
import Aos from 'aos';
import 'aos/dist/aos.css';

function CustomHeroSection({ heading, path, title }) {
    useEffect(() => {
        Aos.init({ duration: '2000', delay: '0' });
    }, []);
    return (
        <div className="flex justify-start items-center text-black relative min-h-[450px]" style={{
            background: `url('${Image_Url}CustomHeroAssets/CustomHeroBgImg.svg')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            width: '100%',
            height: '25rem',
        }}>
            <div className='md:w-[40%] md:pl-20 pl-10'>
                <h1 className='md:text-6xl text-5xl font-bazaar'>{heading} </h1>

                <p className='md:text-5xl text-4xl font-bazaar'>{title}</p>
                <p className='text-lg'>Home / {path}</p>
            </div>
            <img data-aos='fade-right' src={`${Image_Url}CustomHeroAssets/Cup.svg`} className='absolute -bottom-10 left-0 w-18' alt="" />
            <img data-aos='fade-down' src={`${Image_Url}CustomHeroAssets/glass.svg`} className='absolute top-6 md:right-36 right-0 w-18' alt="" />
            <img data-aos='fade-left' src={`${Image_Url}CustomHeroAssets/shopper.svg`} className='absolute md:bottom-16 bottom-8 right-0 w-18' alt="" />
            <img data-aos='fade-up' src={`${Image_Url}CustomHeroAssets/basket.svg`} className='absolute hidden md:block bottom-16 right-[30rem] w-18' alt="" />
        </div>
    )
}

export default CustomHeroSection
