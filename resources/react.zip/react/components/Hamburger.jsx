import React from 'react'

function Hamburger({ firstPage, secondPage }) {
    return (
        <div className="text-white">
            <h1>{firstPage} <span>/ {secondPage}</span> </h1>
        </div>
    )
}

export default Hamburger
