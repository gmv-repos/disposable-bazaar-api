import React, { useEffect, useRef, useState } from 'react'
import '../Custom.css'
import axios from '../../Utils/axios';
import CategorySlider from './CategorySlider';
import { Loader } from '../Loader';

function Categories() {
    const [category, setCategory] = useState('');  // Default empty
    const [categories, setCategories] = useState([]);  // List of categories
    const [categoryList, setCategoryList] = useState([]);  // Products for the selected category
    const [isLoading, setIsLoading] = useState(false); // New state for loading

    // State for drag functionality
    const [isDragging, setIsDragging] = useState(false);
    const [startX, setStartX] = useState(0);
    const [scrollLeft, setScrollLeft] = useState(0);

    const scrollRef = useRef(null);

    const handleMouseDown = (e) => {
        setIsDragging(true);
        setStartX(e.pageX - scrollRef.current.offsetLeft);
        setScrollLeft(scrollRef.current.scrollLeft);
    };

    const handleMouseMove = (e) => {
        if (!isDragging) return;
        e.preventDefault();
        const x = e.pageX - scrollRef.current.offsetLeft;
        const walk = (x - startX) * 2;  // Adjust scroll speed
        scrollRef.current.scrollLeft = scrollLeft - walk;
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                // Fetch categories from the API
                const response = await axios.public.get('product/category');
                const categoryData = response.data.data;

                setCategories(categoryData);

                // Set default category as the first one and fetch its products
                if (categoryData.length > 0) {
                    const firstCategory = categoryData[0];  // First category
                    setCategory(firstCategory.name.trim().toLowerCase());  // Set the first category name
                    fetchCategoryProducts(firstCategory.id);  // Fetch products for the first category
                }
            } catch (error) {
                console.log(error);
            } finally {
                setIsLoading(false)
            }
        };
        fetchData();

        // Clean up mouse events
        const handleMouseLeave = () => setIsDragging(false);
        window.addEventListener('mouseup', handleMouseLeave);
        return () => window.removeEventListener('mouseup', handleMouseLeave);
    }, []);

    const fetchCategoryProducts = async (categoryId) => {
        setIsLoading(true)
        try {
            const response = await axios.public.get(`home/category/${categoryId}/product`);
            setCategoryList(response.data.data);  // Set the products for the selected category
        } catch (error) {
            console.log(error);
        } finally {
            setIsLoading(false)
        }
    };

    const handleCategory = (selectedCategory) => {
        fetchCategoryProducts(selectedCategory.id);  // Fetch products for the clicked category
        setCategory(selectedCategory.name.trim().toLowerCase());  // Set the selected category
    };

    // if (isLoading) return <Loader />

    return (
        <div className="pt-10 ">
            <div className="flex justify-center items-center w-full">
                <ul
                    ref={scrollRef}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                    className="flex text-white cursor-pointer gap-5 text-lg justify-start items-center w-2/3 md:w-1/2 overflow-x-auto whitespace-nowrap scrollbar-hide"
                    style={{ scrollbarWidth: '2px' }}
                >
                    {categories.map((cate, index) => (
                        <li
                            key={index}
                            onClick={() => handleCategory(cate)}
                            className={` mx-3 duration-300 hover:text-gray-300 hover:border-b 
        ${category === cate.name.trim().toLowerCase() ? 'text-white' : 'text-[#9F9F9F]'}`}
                        >
                            {cate.name}
                        </li>
                    ))}

                </ul>
            </div>
            {/* <CategoryCards products={categoryList}/> */}
            <div className="pt-10">
                <div className="flex justify-center items-center px-2 lg:px-20">
                    {isLoading ? (
                        <Loader />
                    ) : (
                        <CategorySlider products={categoryList} />
                    )}

                </div>
            </div>

        </div>
    );
}

export default Categories;
