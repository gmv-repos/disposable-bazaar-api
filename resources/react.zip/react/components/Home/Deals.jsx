import React from 'react'
import { Image_Url } from '../../const'
import { Link } from 'react-router-dom'

function Deals() {
    return (
        <div className="flex justify-center md:py-20">
            <div className="flex md:items-start items-center  md:py-24 md:w-[85%] w-[95%] md:h-[75vh] h-[250px]  justify-end relative rounded-2xl" style={{
                backgroundImage: `url(${Image_Url}HomeAssets/Deals/dealsBgImg2.svg)`,
                backgroundSize: 'cover',        // Cover the entire element
                backgroundRepeat: 'no-repeat',  // Prevent repeating the image
                backgroundPosition: 'center',   // Center the image in the element
                // height: '75vh',                // Full viewport height
                // width: '85%',
            }}>
                <div
                    // data-aos='fade-left'
                    className="flex flex-col md:gap-5 gap-2 my-12 items-start justify-center text-black md:pl-20 pl-5 md:pr-10 pr-2 w-1/2">
                    <h1 className='md:text-6xl leading-7 text-[26px] font-bazaar'>Hot Deals & Special Offers</h1>
                    <p className='hidden md:block md:text-lg text-xs'>Enjoy incredible savings on our top-quality plastic containers. Don’t miss out on these unbeatable prices!</p>
                    <p className='md:hidden block md:text-lg text-xs'>Enjoy incredible savings on our top-quality plastic containers!
                    </p>
                    <Link to='/shop'>
                    <button className=' font-bazaar bg-[#1E7773] text-white md:w-44 md:text-lg text-xs p-3 rounded-lg px5 mt5'>EXPLORE OFFERS   </button>
                    </Link>

                </div>
                <img data-aos='fade-up-right' src={`${Image_Url}HomeAssets/Deals/fork.svg`} className='absolute top-4 md:-left-14 -left-4 md:w-36 w-16' alt="" />
                <img data-aos='fade-up-left' src={`${Image_Url}HomeAssets/Deals/spoon.svg`} className='absolute -bottom-14 md:right-[43%] right-[130px] md:w-36 w-16 ' alt="" />
            </div >
        </div>
    )
}

export default Deals
