import Aos from 'aos';
import 'aos/dist/aos.css';
import React, { useEffect, useState } from 'react'
import { Image_Url } from '../../const';
import { Link } from 'react-router-dom';

function Quality() {
    const [visibleItems, setVisibleItems] = useState('');

    useEffect(() => {
        Aos.init({ duration: '2000', delay: '0' });
    }, []);
    const handleResize = () => {
        if (window.innerWidth < 768) {
            setVisibleItems('HomeAssets/Quality/qualityBgImg2.svg'); // Show 2 items on mobile
        } else {
            setVisibleItems('HomeAssets/Quality/qualityBgImg.svg'); // Show 3 items on larger screens
        }
    };

    useEffect(() => {
        window.addEventListener('resize', handleResize);
        handleResize(); // Call it once on component mount

        return () => window.removeEventListener('resize', handleResize);
    }, []);
    return (
        <div className="pt-10 relative">
            <div className="flex items-center md:h-screen" style={{
                backgroundImage: `url(${Image_Url}${visibleItems})`,
                backgroundSize: 'cover',        // Cover the entire element
                backgroundRepeat: 'no-repeat',  // Prevent repeating the image
                backgroundPosition: 'center',   // Center the image in the element
                // height: '100vh',                // Full viewport height
                width: '100%',
            }}>
                <div data-aos='fade-right' className="flex flex-col text-white md:pl-20 pl-5 gap-3 md:py-60 pt-16 pb-8  md:w-1/2 w-[70%]">
                    <h1 className='md:text-6xl text-4xl font-bazaar'>Quality Disposables for Every Need</h1>
                    <p className=' md:text-xl text-sm font-semibold'>Find the Perfect Product for You</p>
                    <Link to='/shop' >
                    <button className='bg-white text-black md:p-3 p-2 font-bazaar rounded-lg md:text-base md:pt-4 pt-3 text-sm md:px-8 px-4 md:mt-5'>BROWSE NOW</button>
                    </Link>

                </div>
                <img data-aos='fade-up-right' src={`${Image_Url}HomeAssets/Quality/cup.svg`} className='absolute  hidden md:block top-20 left-20 w-32' alt="" />
            </div >
        </div>
    )
}

export default Quality
