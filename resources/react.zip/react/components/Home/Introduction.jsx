import React, { useEffect } from 'react'
import { Image_Url } from '../../const'
import AOS from "aos";
import 'aos/dist/aos.css';
import { Link } from 'react-router-dom';

function Introduction() {
    const para = [
        { web: "food storage is a concern that many households face, especially mommies and wives who work tirelessly to make delicious food for their lovely children and husbands A similar problem that restaurants face when they have to prepare meals and deliver them to the customer, their first priority is to ensure the safety of the food while keeping it warm. This exact problem is what surged us to bring you Disposable Bazar, a pioneer in disposable food containers and other storage accessories for food items in E-commerce, the first of a kind in Pakistan." },
        { mob: 'Food storage is a concern that many households face, especially mommies and wives who work tirelessly to make delicious food for their lovely children and husbands.', }
    ]
    // const sentences = para[0].split('. ');

    useEffect(() => {
        AOS.init({ duration: '2000', delay: '0' });
    }, []);

    return (
        <div className="overflow-hidden relative  text-white md:pt-20 p-5">
            <div data-aos='fade-up' data-aos-duration='3000' className="flex flex-col justify-center items-center sm:gap-5 gap-2 ">
                <h1 className='md:pt-20 pt-0 md:text-6xl text-4xl font-bazaar md:w-3/2 w-11/12 text-center'>Why Choose <br /> Disposable Bazaar ?</h1>

                {/* {sentences.map((sentence, index) => (
                    <p key={index} className='text-center w-11/12'>{sentence[0]}</p>
                ))} */}
                {para.map((p, i) => (
                    <div className='w-11/12 flex flex-col items-center '>
                        <p  className='hidden lg:block text-center md:text-lg text-xs w-full'>{p.web}</p>
                        <p  className='lg:hidden block text-center md:text-lg text-xs w-4/5'>{p.mob}</p>
                    </div >
                ))}

                <Link to='/aboutus'>
                    <button className='bg-[#1E7773] md:p-3 p-2 font-bazaar rounded-lg md:text-base md:pt-4 pt-3 text-sm md:px-8 px-4 md:mt-5'>READ MORE</button>
                </Link>
            </div>
            <img data-aos='fade-up-right' src={`${Image_Url}HomeAssets/Introduction/intro-img01.svg`} className='absolute md:w-40 w-20 md:top-20 bottom-0 md:left-[200px] -left-4' alt="" />
            <img data-aos='fade-up' src={`${Image_Url}HomeAssets/Introduction/intro-img02.svg`} className='absolute md:w-40 w-20 md:top-20 bottom-0 md:right-[200px] -right-8' alt="" />
            <img data-aos='fade-up-left' src={`${Image_Url}HomeAssets/Introduction/intro-img03.svg`} className='absolute md:w-40 w-20 top-0 md:right-0 -right-2' alt="" />
            <img data-aos='fade-right' src={`${Image_Url}HomeAssets/Introduction/intro-img04.svg`} className='absolute md:w-40 w-20 top-0 left-0' alt="" />
        </div>
    )
}

export default Introduction
