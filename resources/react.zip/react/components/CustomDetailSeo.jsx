import { Helmet } from 'react-helmet'

const CustomDetailSeo = ({ title, des, focuskey, canonicalUrl, schema }) => {

    // Utility to strip HTML tags from title if necessary
    const stripHtml = (html) => {
        const doc = new DOMParser().parseFromString(html, 'text/html');
        return doc.body.textContent || "";
    };
    console.log(schema);

    return (
        <Helmet>
            {/* Title */}
            <title>{stripHtml(title) || 'Default Title'}</title>

            {/* Meta Description */}
            <meta name="description" content={des || 'Default description'} />

            {/* Focus Keyword */}
            {focuskey && <meta name="keywords" content={focuskey} />}

            {/* Canonical URL */}
            {canonicalUrl && <link rel="canonical" href={canonicalUrl} />}

            {/* Robots.txt rules */}
            {/* {seoData.robots_txt && <meta name="robots" content={seoData.robots_txt} />} */}

            {/* Schema markup */}
            {schema && (
                <script type="application/ld+json"   >
                    {schema}
                </script>
            )}

            {/* Sitemap URL */}
            {/* {seoData.sitemap_xml && <link rel="sitemap" type="application/xml" href={seoData.sitemap_xml} />} */}

            {/* Optional Google Analytics */}
            <script async src="https://www.google-analytics.com/analytics.js"></script>
        </Helmet>
    )
}

export default CustomDetailSeo