export const Image_Url = "https://ecommerce.thegallerygen.com/public/frontend/assets/";
export const Assets_Url = "https://ecommerce.thegallerygen.com/";
// export const Assets_Url = 'http://localhost/ecommerce-inventory/';
export const Profile_Assets_Url = "https://ecommerce.thegallerygen.com/storage/app/public";
// export const Local_Assets_Url = http://localhost/ecommerce-inventory/
// https://ecommerce.thegallerygen.com/
export const Image_Not_Found = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXcB8kmCDKILwOjlKT8LCcCflFgH9LJnAZDuLnZ5tAsa2-oFQsvD2A37DxYCmeNrvw8PI&usqp=CAU';